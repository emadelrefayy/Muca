import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_lab_user, CurrentUser

router = APIRouter(prefix="/api/clients", tags=["clients"])


@router.get("", response_model=list[schemas.ClientOut])
def list_clients(db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    return db.query(models.Client).filter_by(lab_id=user.lab_id).order_by(models.Client.created_at.desc()).all()


@router.post("", response_model=schemas.ClientOut, status_code=201)
def create_client(body: schemas.ClientCreate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    client = models.Client(lab_id=user.lab_id, **body.model_dump())
    db.add(client)
    db.commit()
    db.refresh(client)
    return client


@router.get("/{client_id}", response_model=schemas.ClientOut)
def get_client(client_id: uuid.UUID, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    client = db.query(models.Client).filter_by(id=client_id, lab_id=user.lab_id).first()
    if not client:
        raise HTTPException(404, "Client not found")
    return client


@router.patch("/{client_id}", response_model=schemas.ClientOut)
def update_client(client_id: uuid.UUID, body: schemas.ClientUpdate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    client = db.query(models.Client).filter_by(id=client_id, lab_id=user.lab_id).first()
    if not client:
        raise HTTPException(404, "Client not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(client, field, value)
    db.commit()
    db.refresh(client)
    return client


@router.delete("/{client_id}", status_code=204)
def delete_client(client_id: uuid.UUID, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    client = db.query(models.Client).filter_by(id=client_id, lab_id=user.lab_id).first()
    if not client:
        raise HTTPException(404, "Client not found")
    db.delete(client)
    db.commit()
