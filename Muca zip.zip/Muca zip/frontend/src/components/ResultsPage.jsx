import React, { useEffect, useState } from "react";
import { FileCheck2, Plus, Send } from "lucide-react";
import Modal from "./Modal";
import StatusBadge from "./StatusBadge";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

const empty = { order_id: "", result_text: "", result_file_path: "", notes: "" };

export default function ResultsPage({ t }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState([]);
  const [pendingOrders, setPendingOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const [{ data }, { data: orders }] = await Promise.all([
      supabase.from("results").select("*, orders(clients(name), services(name))").order("created_at", { ascending: false }),
      supabase.from("orders").select("id, clients(name), services(name)").in("status", ["booked", "in_progress"]).order("booking_date", { ascending: false }),
    ]);
    setRows(data || []);
    setPendingOrders(orders || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function openNew() { setForm(empty); setEditing({}); setError(""); }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const payload = {
      order_id: form.order_id,
      result_text: form.result_text || null,
      result_file_path: form.result_file_path || null,
      notes: form.notes || null,
      lab_id: profile?.lab_id,
      entered_by: profile?.id,
      status: "ready",
      completed_at: new Date().toISOString(),
    };
    const { error: err } = await supabase.from("results").insert(payload);
    if (!err) {
      await supabase.from("orders").update({ status: "completed" }).eq("id", form.order_id);
    }
    setSaving(false);
    if (err) { setError(err.message); return; }
    setEditing(null);
    load();
  }

  async function markSent(row) {
    await supabase.from("results").update({ status: "sent", sent_at: new Date().toISOString() }).eq("id", row.id);
    load();
    // Hook point: once n8n is deployed, call its WhatsApp webhook here with row.order_id
    // so the client is notified their result is ready, per the agreed Phase 4 plan.
  }

  const statusMap = { pending: "pending", ready: "progress", sent: "completed" };
  const statusLabel = { pending: t.resultPending, ready: t.resultReady, sent: t.resultSent };

  return (
    <main className="content">
      <div className="page-head">
        <div>
          <h1>{t.results}</h1>
          <p>{t.resultsSubtitle}</p>
        </div>
        <button className="primary-button" onClick={openNew}><Plus size={16} /> {t.addResult}</button>
      </div>

      <article className="panel">
        <div className="panel-head"><h2>{t.allResults}</h2></div>
        <div className="table-scroll">
          {loading ? (
            <div className="table-state">{t.loading}</div>
          ) : rows.length === 0 ? (
            <div className="table-state"><FileCheck2 size={22} /><p>{t.noResults}</p></div>
          ) : (
            <table>
              <thead>
                <tr><th>{t.client}</th><th>{t.service}</th><th>{t.status}</th><th></th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td>{r.orders?.clients?.name || "—"}</td>
                    <td>{r.orders?.services?.name || "—"}</td>
                    <td><StatusBadge status={statusMap[r.status]} label={statusLabel[r.status]} /></td>
                    <td>
                      {r.status !== "sent" && (
                        <button className="table-action" onClick={() => markSent(r)} title={t.markSent}>
                          <Send size={15} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </article>

      {editing !== null && (
        <Modal title={t.addResult} onClose={() => setEditing(null)}>
          <form onSubmit={handleSave} className="form-grid">
            <label className="field field-full"><span>{t.order}</span>
              <select required value={form.order_id} onChange={(e) => setForm({ ...form, order_id: e.target.value })}>
                <option value="" disabled>{t.selectOrder}</option>
                {pendingOrders.map((o) => (
                  <option key={o.id} value={o.id}>{o.clients?.name || "—"} — {o.services?.name || "—"}</option>
                ))}
              </select>
            </label>
            <label className="field field-full"><span>{t.resultText}</span>
              <textarea rows={4} value={form.result_text} onChange={(e) => setForm({ ...form, result_text: e.target.value })} />
            </label>
            <label className="field field-full"><span>{t.resultFileUrl}</span>
              <input value={form.result_file_path} onChange={(e) => setForm({ ...form, result_file_path: e.target.value })} placeholder="https://..." />
            </label>
            {error && <div className="form-error field-full">{error}</div>}
            <div className="modal-actions field-full">
              <button type="button" className="secondary-button" onClick={() => setEditing(null)}>{t.cancel}</button>
              <button type="submit" className="primary-button" disabled={saving}>{saving ? t.saving : t.save}</button>
            </div>
          </form>
        </Modal>
      )}
    </main>
  );
}
