from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_lab_user, CurrentUser

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/summary", response_model=schemas.DashboardSummary)
def dashboard_summary(db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    clients = db.query(func.count(models.Client.id)).filter_by(lab_id=user.lab_id).scalar() or 0
    orders = db.query(func.count(models.Order.id)).filter_by(lab_id=user.lab_id).scalar() or 0
    pending_results = (
        db.query(func.count(models.Result.id))
        .filter_by(lab_id=user.lab_id, status="pending")
        .scalar() or 0
    )
    revenue = (
        db.query(func.coalesce(func.sum(models.Payment.amount), 0))
        .filter_by(lab_id=user.lab_id, status="paid")
        .scalar() or 0
    )
    return schemas.DashboardSummary(
        clients=clients, orders=orders, pending_results=pending_results, revenue=float(revenue)
    )
