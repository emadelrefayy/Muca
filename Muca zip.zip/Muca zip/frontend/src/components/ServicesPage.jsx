import React, { useEffect, useState } from "react";
import { FlaskConical, Plus, Pencil } from "lucide-react";
import Modal from "./Modal";
import StatusBadge from "./StatusBadge";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

const empty = { name: "", description: "", price: "", duration_minutes: "", status: "active" };

export default function ServicesPage({ t }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const { data, error: err } = await supabase.from("services").select("*").order("name");
    if (!err) setRows(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function openNew() { setForm(empty); setEditing({}); setError(""); }
  function openEdit(row) {
    setForm({ name: row.name, description: row.description || "", price: row.price, duration_minutes: row.duration_minutes, status: row.status });
    setEditing(row); setError("");
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const payload = { ...form, price: Number(form.price), duration_minutes: Number(form.duration_minutes) };
    const isNew = !editing?.id;
    const { error: err } = isNew
      ? await supabase.from("services").insert({ ...payload, lab_id: profile?.lab_id })
      : await supabase.from("services").update(payload).eq("id", editing.id);
    setSaving(false);
    if (err) { setError(err.message); return; }
    setEditing(null);
    load();
  }

  const statusLabel = { active: t.active, inactive: t.inactive };

  return (
    <main className="content">
      <div className="page-head">
        <div>
          <h1>{t.services}</h1>
          <p>{t.servicesSubtitle}</p>
        </div>
        <button className="primary-button" onClick={openNew}><Plus size={16} /> {t.addService}</button>
      </div>

      <article className="panel">
        <div className="panel-head"><h2>{t.allServices}</h2></div>
        <div className="table-scroll">
          {loading ? (
            <div className="table-state">{t.loading}</div>
          ) : rows.length === 0 ? (
            <div className="table-state"><FlaskConical size={22} /><p>{t.noServices}</p></div>
          ) : (
            <table>
              <thead>
                <tr><th>{t.name}</th><th>{t.price}</th><th>{t.duration}</th><th>{t.status}</th><th></th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td>{r.name}</td>
                    <td>{Number(r.price).toLocaleString()} EGP</td>
                    <td>{r.duration_minutes} {t.minutes}</td>
                    <td><StatusBadge status={r.status === "active" ? "completed" : "pending"} label={statusLabel[r.status]} /></td>
                    <td><button className="table-action" onClick={() => openEdit(r)}><Pencil size={15} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </article>

      {editing !== null && (
        <Modal title={editing.id ? t.editService : t.addService} onClose={() => setEditing(null)}>
          <form onSubmit={handleSave} className="form-grid">
            <label className="field field-full"><span>{t.name}</span>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </label>
            <label className="field"><span>{t.price} (EGP)</span>
              <input required type="number" min="0" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
            </label>
            <label className="field"><span>{t.duration} ({t.minutes})</span>
              <input required type="number" min="1" value={form.duration_minutes} onChange={(e) => setForm({ ...form, duration_minutes: e.target.value })} />
            </label>
            <label className="field"><span>{t.status}</span>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option value="active">{t.active}</option>
                <option value="inactive">{t.inactive}</option>
              </select>
            </label>
            <label className="field field-full"><span>{t.description}</span>
              <textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </label>
            {error && <div className="form-error field-full">{error}</div>}
            <div className="modal-actions field-full">
              <button type="button" className="secondary-button" onClick={() => setEditing(null)}>{t.cancel}</button>
              <button type="submit" className="primary-button" disabled={saving}>{saving ? t.saving : t.save}</button>
            </div>
          </form>
        </Modal>
      )}
    </main>
  );
}
