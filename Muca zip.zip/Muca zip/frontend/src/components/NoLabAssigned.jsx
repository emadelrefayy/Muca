import React, { useState } from "react";
import { Copy, Check, LogOut } from "lucide-react";
import Logo from "./Logo";
import { useAuth } from "../context/AuthContext";

export default function NoLabAssigned({ t }) {
  const { session, profileError, signOut } = useAuth();
  const [copied, setCopied] = useState(false);
  const uid = session?.user?.id || "";

  function copy() {
    navigator.clipboard.writeText(uid);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="auth-screen">
      <div className="auth-card">
        <Logo />
        <h1>{t.noLabTitle}</h1>
        <p>{profileError || t.noLabSubtitle}</p>

        <label className="field">
          <span>{t.yourUserId}</span>
          <div className="copy-row">
            <input readOnly value={uid} />
            <button type="button" className="icon-button" onClick={copy} aria-label="Copy">
              {copied ? <Check size={16} /> : <Copy size={16} />}
            </button>
          </div>
        </label>

        <button className="secondary-button auth-submit" onClick={signOut}>
          <LogOut size={16} /> {t.signOut}
        </button>
      </div>
    </div>
  );
}
