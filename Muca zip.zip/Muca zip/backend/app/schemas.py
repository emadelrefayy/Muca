import uuid
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict


class ORMBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- Clients ----------
class ClientCreate(BaseModel):
    name: str
    phone: str
    email: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None


class ClientUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None


class ClientOut(ORMBase):
    id: uuid.UUID
    lab_id: uuid.UUID
    name: str
    phone: str
    email: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime


# ---------- Services ----------
class ServiceCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    duration_minutes: int
    status: str = "active"


class ServiceUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    duration_minutes: Optional[int] = None
    status: Optional[str] = None


class ServiceOut(ORMBase):
    id: uuid.UUID
    lab_id: uuid.UUID
    name: str
    description: Optional[str] = None
    price: float
    duration_minutes: int
    status: str
    created_at: datetime
    updated_at: datetime


# ---------- Staff ----------
class StaffCreate(BaseModel):
    auth_user_id: uuid.UUID
    name: str
    role: str
    phone: Optional[str] = None
    status: str = "active"


class StaffUpdate(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None
    phone: Optional[str] = None
    status: Optional[str] = None


class StaffOut(ORMBase):
    id: uuid.UUID
    lab_id: uuid.UUID
    auth_user_id: uuid.UUID
    name: str
    role: str
    phone: Optional[str] = None
    status: str
    created_at: datetime
    updated_at: datetime


# ---------- Orders ----------
class OrderCreate(BaseModel):
    client_id: uuid.UUID
    service_id: uuid.UUID
    booking_date: datetime
    expected_result_at: Optional[datetime] = None
    notes: Optional[str] = None


class OrderUpdate(BaseModel):
    status: Optional[str] = None
    booking_date: Optional[datetime] = None
    expected_result_at: Optional[datetime] = None
    notes: Optional[str] = None


class OrderOut(ORMBase):
    id: uuid.UUID
    lab_id: uuid.UUID
    client_id: uuid.UUID
    service_id: uuid.UUID
    created_by: Optional[uuid.UUID] = None
    booking_date: datetime
    expected_result_at: Optional[datetime] = None
    status: str
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime


# ---------- Payments ----------
class PaymentCreate(BaseModel):
    order_id: uuid.UUID
    amount: float
    method: str = "cash"
    status: str = "paid"
    reference: Optional[str] = None
    notes: Optional[str] = None


class PaymentUpdate(BaseModel):
    amount: Optional[float] = None
    method: Optional[str] = None
    status: Optional[str] = None
    reference: Optional[str] = None
    notes: Optional[str] = None


class PaymentOut(ORMBase):
    id: uuid.UUID
    lab_id: uuid.UUID
    order_id: uuid.UUID
    amount: float
    method: str
    status: str
    reference: Optional[str] = None
    notes: Optional[str] = None
    paid_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime


# ---------- Results ----------
class ResultCreate(BaseModel):
    order_id: uuid.UUID
    result_text: Optional[str] = None
    result_file_path: Optional[str] = None
    notes: Optional[str] = None


class ResultUpdate(BaseModel):
    result_text: Optional[str] = None
    result_file_path: Optional[str] = None
    status: Optional[str] = None
    notes: Optional[str] = None


class ResultOut(ORMBase):
    id: uuid.UUID
    lab_id: uuid.UUID
    order_id: uuid.UUID
    entered_by: Optional[uuid.UUID] = None
    result_text: Optional[str] = None
    result_file_path: Optional[str] = None
    status: str
    notes: Optional[str] = None
    completed_at: Optional[datetime] = None
    sent_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime


# ---------- Dashboard ----------
class DashboardSummary(BaseModel):
    clients: int
    orders: int
    pending_results: int
    revenue: float
    currency: str = "EGP"
