# Muca

Muca is a clean, bilingual (Arabic/English), RTL/LTR, dark/light-mode laboratory SaaS frontend starter with a FastAPI backend starter.

## Current implementation

- Muca SVG logo integrated from the supplied asset.
- Responsive dashboard UI matching the approved visual direction.
- Arabic RTL / English LTR toggle.
- Dark / Light mode toggle.
- Responsive sidebar and mobile bottom navigation.
- Dashboard KPI cards, recent orders, revenue overview.
- Reusable UI primitives for buttons, cards, badges, inputs and tables.
- FastAPI health endpoint and dashboard summary endpoint.
- Mock data only; no production authentication/database yet.

## Run frontend

```bash
cd frontend
cp .env.example .env   # already pre-filled with the Muca project's public anon key
npm install
npm run dev
```

Open the Vite URL shown in the terminal. First run: use "Create an account" to sign up,
then follow the one-time SQL bootstrap step in `PROJECT_STATUS.md` to link your account
to the lab as its first `lab_manager`. After that, add teammates from the Staff page.

## Run backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in DATABASE_URL, SUPABASE_URL, SUPABASE_JWT_SECRET
uvicorn app.main:app --reload --port 8000
```

API (all `/api/*` routes require a `Bearer <supabase JWT>` header):
- `GET /health`
- `GET /api/dashboard/summary`
- `GET/POST/PATCH/DELETE /api/clients`
- `GET/POST/PATCH/DELETE /api/services`
- `GET/POST/PATCH /api/staff`
- `GET/POST/PATCH /api/orders`
- `GET/POST/PATCH /api/payments`
- `GET/POST/PATCH /api/results`, `POST /api/results/{id}/send`

See `PROJECT_STATUS.md` for exactly what's implemented vs. what's left.

## Next production phases

1. ~~PostgreSQL schema~~ done (see `app/models.py`) — add Alembic migrations next.
2. Wire Supabase Auth into the frontend login and connect the dashboard/pages to the real API instead of mock data.
3. Super Admin dashboard (create labs, manage subscriptions).
4. n8n / WhatsApp agent integration + results-send webhook.
5. Activate RLS as a second layer once the app-level `lab_id` filtering is proven in production.
6. Audit logs, backups, monitoring and production deployment.
