from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    All values are read from environment variables (or a .env file next to
    this app when running locally). Nothing here should be hard-coded with
    real secrets — copy .env.example to .env and fill it in.
    """

    # Supabase Postgres connection string, e.g.:
    # postgresql://postgres:PASSWORD@db.xxxx.supabase.co:5432/postgres
    database_url: str = "postgresql://postgres:postgres@localhost:5432/muca"

    # Supabase project settings, used to verify auth JWTs sent by the frontend
    supabase_url: str = ""
    supabase_jwt_secret: str = ""

    # Comma-separated list of allowed frontend origins
    cors_origins: str = "http://localhost:5173"

    class Config:
        env_file = ".env"


settings = Settings()
