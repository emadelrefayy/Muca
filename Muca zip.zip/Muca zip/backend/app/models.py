import uuid
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, Numeric,
    ForeignKey, DateTime, func
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .database import Base


def uuid_pk():
    return Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


class Lab(Base):
    __tablename__ = "labs"

    id = uuid_pk()
    name = Column(Text, nullable=False)
    status = Column(Text, nullable=False, default="active")
    address = Column(Text)
    email = Column(Text)
    phone = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    clients = relationship("Client", back_populates="lab")
    orders = relationship("Order", back_populates="lab")
    services = relationship("Service", back_populates="lab")
    staff = relationship("Staff", back_populates="lab")
    payments = relationship("Payment", back_populates="lab")
    results = relationship("Result", back_populates="lab")
    subscriptions = relationship("Subscription", back_populates="lab")


class Client(Base):
    __tablename__ = "clients"

    id = uuid_pk()
    lab_id = Column(UUID(as_uuid=True), ForeignKey("labs.id"), nullable=False, index=True)
    name = Column(Text, nullable=False)
    phone = Column(Text, nullable=False)
    email = Column(Text)
    address = Column(Text)
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    lab = relationship("Lab", back_populates="clients")
    orders = relationship("Order", back_populates="client")


class Service(Base):
    __tablename__ = "services"

    id = uuid_pk()
    lab_id = Column(UUID(as_uuid=True), ForeignKey("labs.id"), nullable=False, index=True)
    name = Column(Text, nullable=False)
    description = Column(Text)
    price = Column(Numeric, nullable=False)
    duration_minutes = Column(Integer, nullable=False)
    status = Column(Text, nullable=False, default="active")
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    lab = relationship("Lab", back_populates="services")
    orders = relationship("Order", back_populates="service")


class Staff(Base):
    __tablename__ = "staff"

    id = uuid_pk()
    lab_id = Column(UUID(as_uuid=True), ForeignKey("labs.id"), nullable=False, index=True)
    auth_user_id = Column(UUID(as_uuid=True), nullable=False)
    name = Column(Text, nullable=False)
    role = Column(Text, nullable=False)  # e.g. reception / manager
    phone = Column(Text)
    status = Column(Text, nullable=False, default="active")
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    lab = relationship("Lab", back_populates="staff")


class Order(Base):
    __tablename__ = "orders"

    id = uuid_pk()
    lab_id = Column(UUID(as_uuid=True), ForeignKey("labs.id"), nullable=False, index=True)
    client_id = Column(UUID(as_uuid=True), ForeignKey("clients.id"), nullable=False, index=True)
    service_id = Column(UUID(as_uuid=True), ForeignKey("services.id"), nullable=False, index=True)
    created_by = Column(UUID(as_uuid=True), ForeignKey("staff.id"))
    booking_date = Column(DateTime(timezone=True), nullable=False)
    expected_result_at = Column(DateTime(timezone=True))
    status = Column(Text, nullable=False, default="pending")  # pending/in_progress/completed/cancelled
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    lab = relationship("Lab", back_populates="orders")
    client = relationship("Client", back_populates="orders")
    service = relationship("Service", back_populates="orders")
    payments = relationship("Payment", back_populates="order")
    result = relationship("Result", back_populates="order", uselist=False)


class Payment(Base):
    __tablename__ = "payments"

    id = uuid_pk()
    lab_id = Column(UUID(as_uuid=True), ForeignKey("labs.id"), nullable=False, index=True)
    order_id = Column(UUID(as_uuid=True), ForeignKey("orders.id"), nullable=False, index=True)
    amount = Column(Numeric, nullable=False)
    method = Column(Text, nullable=False, default="cash")
    status = Column(Text, nullable=False, default="pending")  # pending/paid/refunded
    reference = Column(Text)
    notes = Column(Text)
    paid_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    lab = relationship("Lab", back_populates="payments")
    order = relationship("Order", back_populates="payments")


class Result(Base):
    __tablename__ = "results"

    id = uuid_pk()
    lab_id = Column(UUID(as_uuid=True), ForeignKey("labs.id"), nullable=False, index=True)
    order_id = Column(UUID(as_uuid=True), ForeignKey("orders.id"), nullable=False, unique=True, index=True)
    entered_by = Column(UUID(as_uuid=True), ForeignKey("staff.id"))
    result_text = Column(Text)
    result_file_path = Column(Text)
    status = Column(Text, nullable=False, default="pending")  # pending/completed/sent
    notes = Column(Text)
    completed_at = Column(DateTime(timezone=True))
    sent_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    lab = relationship("Lab", back_populates="results")
    order = relationship("Order", back_populates="result")


class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"

    id = uuid_pk()
    name = Column(Text, nullable=False)
    description = Column(Text)
    price = Column(Numeric, nullable=False)
    currency = Column(Text, nullable=False, default="EGP")
    duration_days = Column(Integer, nullable=False)
    max_clients = Column(Integer)
    max_orders = Column(Integer)
    max_staff = Column(Integer)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = uuid_pk()
    lab_id = Column(UUID(as_uuid=True), ForeignKey("labs.id"), nullable=False, index=True)
    plan_id = Column(UUID(as_uuid=True), ForeignKey("subscription_plans.id"), nullable=False)
    status = Column(Text, nullable=False, default="active")
    start_date = Column(DateTime(timezone=True), nullable=False)
    end_date = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    lab = relationship("Lab", back_populates="subscriptions")


class SuperAdmin(Base):
    __tablename__ = "super_admins"

    id = uuid_pk()
    auth_user_id = Column(UUID(as_uuid=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
