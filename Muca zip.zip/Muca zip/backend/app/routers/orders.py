import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_lab_user, CurrentUser

router = APIRouter(prefix="/api/orders", tags=["orders"])


@router.get("", response_model=list[schemas.OrderOut])
def list_orders(
    status: str | None = None,
    db: Session = Depends(get_db),
    user: CurrentUser = Depends(require_lab_user),
):
    q = db.query(models.Order).filter_by(lab_id=user.lab_id)
    if status:
        q = q.filter_by(status=status)
    return q.order_by(models.Order.booking_date.desc()).all()


@router.post("", response_model=schemas.OrderOut, status_code=201)
def create_order(body: schemas.OrderCreate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    client = db.query(models.Client).filter_by(id=body.client_id, lab_id=user.lab_id).first()
    if not client:
        raise HTTPException(404, "Client not found")
    service = db.query(models.Service).filter_by(id=body.service_id, lab_id=user.lab_id).first()
    if not service:
        raise HTTPException(404, "Service not found")

    order = models.Order(
        lab_id=user.lab_id,
        created_by=user.staff.id if user.staff else None,
        **body.model_dump(),
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    return order


@router.get("/{order_id}", response_model=schemas.OrderOut)
def get_order(order_id: uuid.UUID, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    order = db.query(models.Order).filter_by(id=order_id, lab_id=user.lab_id).first()
    if not order:
        raise HTTPException(404, "Order not found")
    return order


@router.patch("/{order_id}", response_model=schemas.OrderOut)
def update_order(order_id: uuid.UUID, body: schemas.OrderUpdate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    order = db.query(models.Order).filter_by(id=order_id, lab_id=user.lab_id).first()
    if not order:
        raise HTTPException(404, "Order not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(order, field, value)
    db.commit()
    db.refresh(order)
    return order
