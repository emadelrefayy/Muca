import React, { useEffect, useState } from "react";
import { UserCog, Plus, Pencil } from "lucide-react";
import Modal from "./Modal";
import StatusBadge from "./StatusBadge";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

const empty = { auth_user_id: "", name: "", role: "receptionist", phone: "", status: "active" };

export default function StaffPage({ t }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const { data, error: err } = await supabase.from("staff").select("*").order("name");
    if (!err) setRows(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function openNew() { setForm(empty); setEditing({}); setError(""); }
  function openEdit(row) {
    setForm({ auth_user_id: row.auth_user_id, name: row.name, role: row.role, phone: row.phone || "", status: row.status });
    setEditing(row); setError("");
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const isNew = !editing?.id;
    let err;
    if (isNew) {
      ({ error: err } = await supabase.from("staff").insert({ ...form, lab_id: profile?.lab_id }));
    } else {
      const { auth_user_id, ...editable } = form; // auth_user_id is not changed after creation
      ({ error: err } = await supabase.from("staff").update(editable).eq("id", editing.id));
    }
    setSaving(false);
    if (err) { setError(err.message); return; }
    setEditing(null);
    load();
  }

  const roleLabel = { receptionist: t.receptionist, lab_manager: t.labManagerRole };
  const statusLabel = { active: t.active, inactive: t.inactive };

  return (
    <main className="content">
      <div className="page-head">
        <div>
          <h1>{t.staff}</h1>
          <p>{t.staffSubtitle}</p>
        </div>
        <button className="primary-button" onClick={openNew}><Plus size={16} /> {t.addStaff}</button>
      </div>

      <article className="panel">
        <div className="panel-head"><h2>{t.allStaff}</h2></div>
        <div className="table-scroll">
          {loading ? (
            <div className="table-state">{t.loading}</div>
          ) : rows.length === 0 ? (
            <div className="table-state"><UserCog size={22} /><p>{t.noStaff}</p></div>
          ) : (
            <table>
              <thead>
                <tr><th>{t.name}</th><th>{t.role}</th><th>{t.phone}</th><th>{t.status}</th><th></th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td>{r.name}</td>
                    <td>{roleLabel[r.role] || r.role}</td>
                    <td>{r.phone || "—"}</td>
                    <td><StatusBadge status={r.status === "active" ? "completed" : "pending"} label={statusLabel[r.status]} /></td>
                    <td><button className="table-action" onClick={() => openEdit(r)}><Pencil size={15} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </article>

      {editing !== null && (
        <Modal title={editing.id ? t.editStaff : t.addStaff} onClose={() => setEditing(null)}>
          <form onSubmit={handleSave} className="form-grid">
            {!editing.id && (
              <label className="field field-full"><span>{t.userId}</span>
                <input required value={form.auth_user_id} onChange={(e) => setForm({ ...form, auth_user_id: e.target.value })} placeholder={t.userIdHint} />
              </label>
            )}
            <label className="field"><span>{t.name}</span>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </label>
            <label className="field"><span>{t.phone}</span>
              <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </label>
            <label className="field"><span>{t.role}</span>
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                <option value="receptionist">{t.receptionist}</option>
                <option value="lab_manager">{t.labManagerRole}</option>
              </select>
            </label>
            <label className="field"><span>{t.status}</span>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option value="active">{t.active}</option>
                <option value="inactive">{t.inactive}</option>
              </select>
            </label>
            {error && <div className="form-error field-full">{error}</div>}
            <div className="modal-actions field-full">
              <button type="button" className="secondary-button" onClick={() => setEditing(null)}>{t.cancel}</button>
              <button type="submit" className="primary-button" disabled={saving}>{saving ? t.saving : t.save}</button>
            </div>
          </form>
        </Modal>
      )}
    </main>
  );
}
