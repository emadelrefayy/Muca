import uuid
from dataclasses import dataclass

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from sqlalchemy.orm import Session

from .config import settings
from .database import get_db
from . import models

bearer_scheme = HTTPBearer()


@dataclass
class CurrentUser:
    auth_user_id: uuid.UUID
    is_super_admin: bool
    staff: "models.Staff | None"

    @property
    def lab_id(self):
        return self.staff.lab_id if self.staff else None


def _decode_token(token: str) -> dict:
    """
    Verifies the JWT issued by Supabase Auth for the logged-in user.
    Supabase signs project JWTs with the project's JWT secret (HS256).
    """
    if not settings.supabase_jwt_secret:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Server auth is not configured (SUPABASE_JWT_SECRET missing).",
        )
    try:
        payload = jwt.decode(
            token,
            settings.supabase_jwt_secret,
            algorithms=["HS256"],
            audience="authenticated",
        )
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")
    return payload


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> CurrentUser:
    payload = _decode_token(credentials.credentials)
    auth_user_id = uuid.UUID(payload["sub"])

    super_admin = db.query(models.SuperAdmin).filter_by(auth_user_id=auth_user_id).first()
    staff = db.query(models.Staff).filter_by(auth_user_id=auth_user_id, status="active").first()

    if not super_admin and not staff:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No lab membership found for this user")

    return CurrentUser(auth_user_id=auth_user_id, is_super_admin=bool(super_admin), staff=staff)


def require_lab_user(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
    """Use on tenant-scoped routes: every non-super-admin request must belong to a lab."""
    if not user.is_super_admin and user.lab_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User has no lab assigned")
    return user
