# Muca — Implementation Status

## Live Supabase project
- Project "Muca" (ref `grcobobbhrqjanarptln`) is provisioned and connected.
- All 10 tables exist with RLS **already enabled and policies already written**
  (clients/orders/services/staff select+insert+update scoped to same lab via
  `auth.uid()` → staff.lab_id; super_admins manage labs/subscription_plans/subscriptions).
  This is ahead of the original phased plan (RLS was to be deferred) — it's done, so the
  app now relies on Postgres RLS as the real tenant-isolation layer, not just app-level filtering.
- 1 lab, 1 subscription plan, 1 super_admin row exist; 0 staff/clients/orders yet (fresh DB).

## Done this round — frontend is now fully wired to Supabase (no more mock data)
- `@supabase/supabase-js` client + `.env` template (pre-filled with the project's public anon key).
- **Auth**: sign in / sign up screens, session handling, and a "no lab yet" screen that shows
  a new user their auth User ID to hand to their manager (see "Bootstrapping" below — there's
  no admin API available from the frontend with just the anon key, so the first-manager step
  is manual by design).
- **Dashboard**: KPI cards, recent orders, and the revenue chart now come from real aggregate
  queries against `clients`/`orders`/`results`/`payments`.
- **Clients, Services, Staff, Orders, Payments, Results** pages: full list + add (and
  edit where applicable) forms, all styled with the exact same panel/table/StatusBadge/
  modal design language as the original dashboard mockup. Orders page lets reception change
  status inline; Results page has a "mark as sent" action stubbed as the future WhatsApp hook point.
- New shared CSS for modals, forms, and the auth screens, extending (not replacing) the
  original design tokens/colors.
- Bilingual (EN/AR) labels added for every new screen in `translations.js`.

## Bootstrapping a lab + your first login (manual, one-time, via SQL)
There's no staff yet, so nobody can log in and see a lab. Two ways to create the first user:
1. Open the app → "Create an account" (sign up) with your email/password.
2. You'll land on the "No lab access yet" screen showing your **User ID** — copy it.
3. Run this SQL once in Supabase (SQL Editor), using the User ID from step 2 and the existing
   lab id (`select id from labs;`):
   ```sql
   insert into staff (lab_id, auth_user_id, name, role, status)
   values ('<lab-id>', '<your-user-id>', 'Your Name', 'lab_manager', 'active');
   ```
4. Reload the app — you're in, and from the Staff page you can now add teammates by having
   them sign up and pasting their User ID into the "Add Staff" form.

## Still not production-ready / remaining
- **FastAPI backend** (built in the previous round, in `/backend`) is now optional — since RLS
  + the Supabase JS client handle auth and tenant isolation directly from the frontend, the
  simplest path is to skip deploying it for the MVP and revisit it only if/when you need
  server-side logic (e.g. the n8n/WhatsApp webhook, admin-only bulk operations).
- **Super Admin dashboard**: not built — needed to create new labs and manage subscriptions
  (currently only doable via SQL, like the bootstrap step above).
- **n8n / WhatsApp agent**: not started — booking, RAG Q&A, "is my result ready", and the
  results-send webhook (the `/results` page's "mark as sent" button is the hook point).
- **File uploads for results**: currently a plain URL field; wiring real uploads needs
  Supabase Storage (a bucket + policies + an upload widget).
- **Doctor/lab-manager "case summary" / patient search** page from the original vision: not built.
- Production deployment (domain, hosting for the frontend build), monitoring/alerts, audit logs.
