import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_lab_user, CurrentUser

router = APIRouter(prefix="/api/services", tags=["services"])


@router.get("", response_model=list[schemas.ServiceOut])
def list_services(db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    return db.query(models.Service).filter_by(lab_id=user.lab_id).order_by(models.Service.name).all()


@router.post("", response_model=schemas.ServiceOut, status_code=201)
def create_service(body: schemas.ServiceCreate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    service = models.Service(lab_id=user.lab_id, **body.model_dump())
    db.add(service)
    db.commit()
    db.refresh(service)
    return service


@router.patch("/{service_id}", response_model=schemas.ServiceOut)
def update_service(service_id: uuid.UUID, body: schemas.ServiceUpdate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    service = db.query(models.Service).filter_by(id=service_id, lab_id=user.lab_id).first()
    if not service:
        raise HTTPException(404, "Service not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(service, field, value)
    db.commit()
    db.refresh(service)
    return service


@router.delete("/{service_id}", status_code=204)
def delete_service(service_id: uuid.UUID, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    service = db.query(models.Service).filter_by(id=service_id, lab_id=user.lab_id).first()
    if not service:
        raise HTTPException(404, "Service not found")
    db.delete(service)
    db.commit()
