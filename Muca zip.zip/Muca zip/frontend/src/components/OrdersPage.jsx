import React, { useEffect, useState } from "react";
import { ClipboardList, Plus, Pencil } from "lucide-react";
import Modal from "./Modal";
import StatusBadge from "./StatusBadge";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

const empty = { client_id: "", service_id: "", booking_date: "", expected_result_at: "", notes: "" };

export default function OrdersPage({ t }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState([]);
  const [clients, setClients] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const [{ data }, { data: cl }, { data: sv }] = await Promise.all([
      supabase.from("orders").select("*, clients(name), services(name, price)").order("booking_date", { ascending: false }),
      supabase.from("clients").select("id, name").order("name"),
      supabase.from("services").select("id, name, price").eq("status", "active").order("name"),
    ]);
    setRows(data || []);
    setClients(cl || []);
    setServices(sv || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function openNew() { setForm(empty); setEditing({}); setError(""); }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const payload = {
      client_id: form.client_id,
      service_id: form.service_id,
      booking_date: form.booking_date ? new Date(form.booking_date).toISOString() : new Date().toISOString(),
      expected_result_at: form.expected_result_at ? new Date(form.expected_result_at).toISOString() : null,
      notes: form.notes || null,
      lab_id: profile?.lab_id,
      created_by: profile?.id,
    };
    const { error: err } = await supabase.from("orders").insert(payload);
    setSaving(false);
    if (err) { setError(err.message); return; }
    setEditing(null);
    load();
  }

  async function updateStatus(row, status) {
    await supabase.from("orders").update({ status }).eq("id", row.id);
    load();
  }

  const statusMap = { booked: "pending", in_progress: "progress", completed: "completed", cancelled: "pending" };
  const statusLabel = { booked: t.booked, in_progress: t.progress, completed: t.completed, cancelled: t.cancelled };

  return (
    <main className="content">
      <div className="page-head">
        <div>
          <h1>{t.orders}</h1>
          <p>{t.ordersSubtitle}</p>
        </div>
        <button className="primary-button" onClick={openNew}><Plus size={16} /> {t.addOrder}</button>
      </div>

      <article className="panel">
        <div className="panel-head"><h2>{t.allOrders}</h2></div>
        <div className="table-scroll">
          {loading ? (
            <div className="table-state">{t.loading}</div>
          ) : rows.length === 0 ? (
            <div className="table-state"><ClipboardList size={22} /><p>{t.noOrders}</p></div>
          ) : (
            <table>
              <thead>
                <tr><th>{t.client}</th><th>{t.service}</th><th>{t.status}</th><th>{t.deliveryDate}</th><th>{t.amount}</th><th></th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td>{r.clients?.name || "—"}</td>
                    <td>{r.services?.name || "—"}</td>
                    <td><StatusBadge status={statusMap[r.status]} label={statusLabel[r.status]} /></td>
                    <td>{r.expected_result_at ? new Date(r.expected_result_at).toLocaleDateString() : "—"}</td>
                    <td>{r.services?.price ? `${Number(r.services.price).toLocaleString()} EGP` : "—"}</td>
                    <td>
                      <select className="inline-select" value={r.status} onChange={(e) => updateStatus(r, e.target.value)}>
                        <option value="booked">{t.booked}</option>
                        <option value="in_progress">{t.progress}</option>
                        <option value="completed">{t.completed}</option>
                        <option value="cancelled">{t.cancelled}</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </article>

      {editing !== null && (
        <Modal title={t.addOrder} onClose={() => setEditing(null)}>
          <form onSubmit={handleSave} className="form-grid">
            <label className="field"><span>{t.client}</span>
              <select required value={form.client_id} onChange={(e) => setForm({ ...form, client_id: e.target.value })}>
                <option value="" disabled>{t.selectClient}</option>
                {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
            <label className="field"><span>{t.service}</span>
              <select required value={form.service_id} onChange={(e) => setForm({ ...form, service_id: e.target.value })}>
                <option value="" disabled>{t.selectService}</option>
                {services.map((s) => <option key={s.id} value={s.id}>{s.name} — {Number(s.price).toLocaleString()} EGP</option>)}
              </select>
            </label>
            <label className="field"><span>{t.bookingDate}</span>
              <input type="datetime-local" value={form.booking_date} onChange={(e) => setForm({ ...form, booking_date: e.target.value })} />
            </label>
            <label className="field"><span>{t.deliveryDate}</span>
              <input type="datetime-local" value={form.expected_result_at} onChange={(e) => setForm({ ...form, expected_result_at: e.target.value })} />
            </label>
            <label className="field field-full"><span>{t.notes}</span>
              <textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </label>
            {error && <div className="form-error field-full">{error}</div>}
            <div className="modal-actions field-full">
              <button type="button" className="secondary-button" onClick={() => setEditing(null)}>{t.cancel}</button>
              <button type="submit" className="primary-button" disabled={saving}>{saving ? t.saving : t.save}</button>
            </div>
          </form>
        </Modal>
      )}
    </main>
  );
}
