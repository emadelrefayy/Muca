import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_lab_user, CurrentUser

router = APIRouter(prefix="/api/staff", tags=["staff"])


@router.get("", response_model=list[schemas.StaffOut])
def list_staff(db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    return db.query(models.Staff).filter_by(lab_id=user.lab_id).order_by(models.Staff.name).all()


@router.post("", response_model=schemas.StaffOut, status_code=201)
def create_staff(body: schemas.StaffCreate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    # Only a manager/doctor role (or super admin) should add staff — enforce in real deployment
    # via a role check once role naming is finalized; left open here so the frontend can wire
    # "doctor/manager adds reception replacement" per the agreed spec.
    member = models.Staff(lab_id=user.lab_id, **body.model_dump())
    db.add(member)
    db.commit()
    db.refresh(member)
    return member


@router.patch("/{staff_id}", response_model=schemas.StaffOut)
def update_staff(staff_id: uuid.UUID, body: schemas.StaffUpdate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    member = db.query(models.Staff).filter_by(id=staff_id, lab_id=user.lab_id).first()
    if not member:
        raise HTTPException(404, "Staff member not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(member, field, value)
    db.commit()
    db.refresh(member)
    return member
