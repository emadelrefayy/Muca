import React, { useEffect, useState } from "react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import PlaceholderPage from "./components/PlaceholderPage";
import ClientsPage from "./components/ClientsPage";
import ServicesPage from "./components/ServicesPage";
import StaffPage from "./components/StaffPage";
import OrdersPage from "./components/OrdersPage";
import PaymentsPage from "./components/PaymentsPage";
import ResultsPage from "./components/ResultsPage";
import Login from "./components/Login";
import NoLabAssigned from "./components/NoLabAssigned";
import { translations } from "./i18n/translations";
import { AuthProvider, useAuth } from "./context/AuthContext";

const pageMap = {
  dashboard: Dashboard,
  clients: ClientsPage,
  services: ServicesPage,
  orders: OrdersPage,
  results: ResultsPage,
  payments: PaymentsPage,
  staff: StaffPage,
};

function Shell() {
  const [lang, setLang] = useState(() => localStorage.getItem("muca-lang") || "en");
  const [dark, setDark] = useState(() => localStorage.getItem("muca-theme") !== "light");
  const [active, setActive] = useState("dashboard");
  const [open, setOpen] = useState(false);
  const { session, loading, profile, isSuperAdmin } = useAuth();

  const t = translations[lang];

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.body.dataset.theme = dark ? "dark" : "light";
    localStorage.setItem("muca-lang", lang);
    localStorage.setItem("muca-theme", dark ? "dark" : "light");
  }, [lang, dark]);

  if (loading) {
    return (
      <div className={`app ${dark ? "theme-dark" : "theme-light"}`}>
        <div className="auth-screen"><p>{t.loading}</p></div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className={`app ${dark ? "theme-dark" : "theme-light"}`}>
        <Login t={t} />
      </div>
    );
  }

  if (!profile && !isSuperAdmin) {
    return (
      <div className={`app ${dark ? "theme-dark" : "theme-light"}`}>
        <NoLabAssigned t={t} />
      </div>
    );
  }

  const ActivePage = pageMap[active];

  return (
    <div className={`app ${dark ? "theme-dark" : "theme-light"}`}>
      <Sidebar t={t} active={active} setActive={setActive} open={open} setOpen={setOpen} />
      <div className="main-area">
        <Header lang={lang} setLang={setLang} dark={dark} setDark={setDark} setOpen={setOpen} t={t} />
        {ActivePage ? <ActivePage t={t} /> : <PlaceholderPage title={t[active]} />}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}
