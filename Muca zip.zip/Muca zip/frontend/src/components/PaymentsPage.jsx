import React, { useEffect, useState } from "react";
import { CreditCard, Plus } from "lucide-react";
import Modal from "./Modal";
import StatusBadge from "./StatusBadge";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

const empty = { order_id: "", amount: "", method: "cash", status: "paid", reference: "", notes: "" };

export default function PaymentsPage({ t }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState([]);
  const [unpaidOrders, setUnpaidOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const [{ data }, { data: orders }] = await Promise.all([
      supabase.from("payments").select("*, orders(clients(name), services(name, price))").order("created_at", { ascending: false }),
      supabase.from("orders").select("id, clients(name), services(name, price)").order("booking_date", { ascending: false }).limit(50),
    ]);
    setRows(data || []);
    setUnpaidOrders(orders || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function openNew() { setForm(empty); setEditing({}); setError(""); }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const payload = {
      order_id: form.order_id,
      amount: Number(form.amount),
      method: form.method,
      status: form.status,
      reference: form.reference || null,
      notes: form.notes || null,
      lab_id: profile?.lab_id,
      paid_at: form.status === "paid" ? new Date().toISOString() : null,
    };
    const { error: err } = await supabase.from("payments").insert(payload);
    setSaving(false);
    if (err) { setError(err.message); return; }
    setEditing(null);
    load();
  }

  const statusMap = { paid: "completed", pending: "pending", refunded: "progress", failed: "pending" };
  const statusLabel = { paid: t.paid, pending: t.pendingPayment, refunded: t.refunded, failed: t.failed };
  const methodLabel = { cash: t.cash, card: t.card, bank_transfer: t.bankTransfer };

  return (
    <main className="content">
      <div className="page-head">
        <div>
          <h1>{t.payments}</h1>
          <p>{t.paymentsSubtitle}</p>
        </div>
        <button className="primary-button" onClick={openNew}><Plus size={16} /> {t.recordPayment}</button>
      </div>

      <article className="panel">
        <div className="panel-head"><h2>{t.allPayments}</h2></div>
        <div className="table-scroll">
          {loading ? (
            <div className="table-state">{t.loading}</div>
          ) : rows.length === 0 ? (
            <div className="table-state"><CreditCard size={22} /><p>{t.noPayments}</p></div>
          ) : (
            <table>
              <thead>
                <tr><th>{t.client}</th><th>{t.service}</th><th>{t.amount}</th><th>{t.method}</th><th>{t.status}</th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td>{r.orders?.clients?.name || "—"}</td>
                    <td>{r.orders?.services?.name || "—"}</td>
                    <td>{Number(r.amount).toLocaleString()} EGP</td>
                    <td>{methodLabel[r.method] || r.method}</td>
                    <td><StatusBadge status={statusMap[r.status]} label={statusLabel[r.status]} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </article>

      {editing !== null && (
        <Modal title={t.recordPayment} onClose={() => setEditing(null)}>
          <form onSubmit={handleSave} className="form-grid">
            <label className="field field-full"><span>{t.order}</span>
              <select required value={form.order_id} onChange={(e) => setForm({ ...form, order_id: e.target.value })}>
                <option value="" disabled>{t.selectOrder}</option>
                {unpaidOrders.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.clients?.name || "—"} — {o.services?.name || "—"}
                  </option>
                ))}
              </select>
            </label>
            <label className="field"><span>{t.amount} (EGP)</span>
              <input required type="number" min="0" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
            </label>
            <label className="field"><span>{t.method}</span>
              <select value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}>
                <option value="cash">{t.cash}</option>
                <option value="card">{t.card}</option>
                <option value="bank_transfer">{t.bankTransfer}</option>
              </select>
            </label>
            <label className="field"><span>{t.status}</span>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option value="paid">{t.paid}</option>
                <option value="pending">{t.pendingPayment}</option>
                <option value="refunded">{t.refunded}</option>
                <option value="failed">{t.failed}</option>
              </select>
            </label>
            <label className="field"><span>{t.reference}</span>
              <input value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} />
            </label>
            {error && <div className="form-error field-full">{error}</div>}
            <div className="modal-actions field-full">
              <button type="button" className="secondary-button" onClick={() => setEditing(null)}>{t.cancel}</button>
              <button type="submit" className="primary-button" disabled={saving}>{saving ? t.saving : t.save}</button>
            </div>
          </form>
        </Modal>
      )}
    </main>
  );
}
