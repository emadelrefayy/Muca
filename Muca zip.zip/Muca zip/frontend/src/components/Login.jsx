import React, { useState } from "react";
import { LogIn, UserPlus } from "lucide-react";
import Logo from "./Logo";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

export default function Login({ t }) {
  const { signIn } = useAuth();
  const [mode, setMode] = useState("signin"); // signin | signup
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setNotice("");
    setBusy(true);
    if (mode === "signin") {
      const { error: err } = await signIn(email, password);
      if (err) setError(err.message);
    } else {
      const { error: err } = await supabase.auth.signUp({ email, password });
      if (err) setError(err.message);
      else setNotice(t.signupNotice);
    }
    setBusy(false);
  }

  return (
    <div className="auth-screen">
      <form className="auth-card" onSubmit={handleSubmit}>
        <Logo />
        <h1>{mode === "signin" ? t.loginTitle : t.signupTitle}</h1>
        <p>{mode === "signin" ? t.loginSubtitle : t.signupSubtitle}</p>

        <label className="field">
          <span>{t.email}</span>
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@lab.com" />
        </label>

        <label className="field">
          <span>{t.password}</span>
          <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </label>

        {error && <div className="form-error">{error}</div>}
        {notice && <div className="form-notice">{notice}</div>}

        <button className="primary-button auth-submit" type="submit" disabled={busy}>
          {mode === "signin" ? <LogIn size={16} /> : <UserPlus size={16} />}
          {busy ? t.loggingIn : mode === "signin" ? t.login : t.createAccount}
        </button>

        <button
          type="button"
          className="link-button auth-switch"
          onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(""); setNotice(""); }}
        >
          {mode === "signin" ? t.switchToSignup : t.switchToSignin}
        </button>
      </form>
    </div>
  );
}
