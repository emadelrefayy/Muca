import React, { useEffect, useState } from "react";
import { UsersRound, ClipboardList, FlaskConical, CreditCard, CalendarDays, MoreVertical } from "lucide-react";
import StatCard from "./StatCard";
import StatusBadge from "./StatusBadge";
import RevenueChart from "./RevenueChart";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

const statusMap = { booked: "pending", in_progress: "progress", completed: "completed", cancelled: "pending" };

export default function Dashboard({ t }) {
  const { profile, lab } = useAuth();
  const [summary, setSummary] = useState({ clients: 0, orders: 0, pendingResults: 0, revenue: 0 });
  const [recentOrders, setRecentOrders] = useState([]);
  const [revenuePoints, setRevenuePoints] = useState([]);
  const [loading, setLoading] = useState(true);

  const statusLabel = { completed: t.completed, pending: t.pending, progress: t.progress };

  useEffect(() => {
    async function load() {
      setLoading(true);
      const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
      const sevenDaysAgo = new Date(); sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6); sevenDaysAgo.setHours(0, 0, 0, 0);

      const [clientsCount, ordersToday, pendingResults, paymentsToday, recent, weekPayments] = await Promise.all([
        supabase.from("clients").select("id", { count: "exact", head: true }),
        supabase.from("orders").select("id", { count: "exact", head: true }).gte("booking_date", startOfDay.toISOString()),
        supabase.from("results").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("payments").select("amount").eq("status", "paid").gte("paid_at", startOfDay.toISOString()),
        supabase.from("orders").select("status, booking_date, clients(name), services(name, price)").order("booking_date", { ascending: false }).limit(5),
        supabase.from("payments").select("amount, paid_at").eq("status", "paid").gte("paid_at", sevenDaysAgo.toISOString()),
      ]);

      const revenueToday = (paymentsToday.data || []).reduce((sum, p) => sum + Number(p.amount), 0);

      setSummary({
        clients: clientsCount.count || 0,
        orders: ordersToday.count || 0,
        pendingResults: pendingResults.count || 0,
        revenue: revenueToday,
      });

      setRecentOrders(recent.data || []);

      const byDay = {};
      (weekPayments.data || []).forEach((p) => {
        const day = new Date(p.paid_at).toISOString().slice(0, 10);
        byDay[day] = (byDay[day] || 0) + Number(p.amount);
      });
      const points = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date(); d.setDate(d.getDate() - i);
        points.push(byDay[d.toISOString().slice(0, 10)] || 0);
      }
      setRevenuePoints(points);
      setLoading(false);
    }
    load();
  }, []);

  return (
    <main className="content">
      <div className="page-head">
        <div>
          <h1>{t.greeting.replace("Ahmed", profile?.name || "").replace("أحمد", profile?.name || "")} <span>👋</span></h1>
          <p>{lab?.name ? `${t.subtitle} (${lab.name})` : t.subtitle}</p>
        </div>
        <button className="date-button"><CalendarDays size={17} /> {new Date().toLocaleDateString()} <span>⌄</span></button>
      </div>

      <section className="stats-grid">
        <StatCard icon={UsersRound} title={t.totalClients} value={summary.clients.toLocaleString()} change={0} color="blue" note={t.fromLastMonth} />
        <StatCard icon={ClipboardList} title={t.ordersToday} value={summary.orders} change={0} color="purple" note={t.fromYesterday} />
        <StatCard icon={FlaskConical} title={t.pendingResults} value={summary.pendingResults} change={0} color="orange" note={t.fromYesterday} />
        <StatCard icon={CreditCard} title={t.todaysRevenue} value={`${summary.revenue.toLocaleString()} EGP`} change={0} color="green" note={t.fromYesterday} />
      </section>

      <section className="dashboard-grid">
        <article className="panel orders-panel">
          <div className="panel-head">
            <h2>{t.recentOrders}</h2>
          </div>
          <div className="table-scroll">
            {loading ? (
              <div className="table-state">{t.loading}</div>
            ) : recentOrders.length === 0 ? (
              <div className="table-state">{t.noOrders}</div>
            ) : (
              <table>
                <thead>
                  <tr><th>{t.client}</th><th>{t.service}</th><th>{t.status}</th><th>{t.deliveryDate}</th><th>{t.amount}</th><th></th></tr>
                </thead>
                <tbody>
                  {recentOrders.map((o, i) => (
                    <tr key={i}>
                      <td>{o.clients?.name || "—"}</td>
                      <td>{o.services?.name || "—"}</td>
                      <td><StatusBadge status={statusMap[o.status]} label={statusLabel[statusMap[o.status]]} /></td>
                      <td>{new Date(o.booking_date).toLocaleDateString()}</td>
                      <td>{o.services?.price ? `${Number(o.services.price).toLocaleString()} EGP` : "—"}</td>
                      <td><button className="table-action"><MoreVertical size={17}/></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </article>

        <article className="panel revenue-panel">
          <div className="panel-head">
            <h2>{t.revenueOverview}</h2>
            <button className="select-button">{t.last7Days} <span>⌄</span></button>
          </div>
          <div className="revenue-value">
            <strong>{revenuePoints.reduce((a, b) => a + b, 0).toLocaleString()} <small>EGP</small></strong>
            <span>{t.last7Days}</span>
          </div>
          <RevenueChart points={revenuePoints.length ? revenuePoints : [0, 0, 0, 0, 0, 0, 0]} />
        </article>
      </section>
    </main>
  );
}
