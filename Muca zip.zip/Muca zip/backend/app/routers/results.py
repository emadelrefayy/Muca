import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_lab_user, CurrentUser

router = APIRouter(prefix="/api/results", tags=["results"])


@router.get("", response_model=list[schemas.ResultOut])
def list_results(db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    return db.query(models.Result).filter_by(lab_id=user.lab_id).order_by(models.Result.created_at.desc()).all()


@router.post("", response_model=schemas.ResultOut, status_code=201)
def create_result(body: schemas.ResultCreate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    order = db.query(models.Order).filter_by(id=body.order_id, lab_id=user.lab_id).first()
    if not order:
        raise HTTPException(404, "Order not found")
    existing = db.query(models.Result).filter_by(order_id=body.order_id).first()
    if existing:
        raise HTTPException(409, "Result already exists for this order")

    result = models.Result(
        lab_id=user.lab_id,
        entered_by=user.staff.id if user.staff else None,
        status="completed",
        completed_at=datetime.now(timezone.utc),
        **body.model_dump(),
    )
    db.add(result)
    order.status = "completed"
    db.commit()
    db.refresh(result)
    return result


@router.patch("/{result_id}", response_model=schemas.ResultOut)
def update_result(result_id: uuid.UUID, body: schemas.ResultUpdate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    result = db.query(models.Result).filter_by(id=result_id, lab_id=user.lab_id).first()
    if not result:
        raise HTTPException(404, "Result not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(result, field, value)
    db.commit()
    db.refresh(result)
    return result


@router.post("/{result_id}/send", response_model=schemas.ResultOut)
def send_result(result_id: uuid.UUID, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    """
    Marks a result as sent. Wire this to the n8n WhatsApp webhook (Phase 4)
    by calling it here before committing sent_at, once n8n is deployed.
    """
    result = db.query(models.Result).filter_by(id=result_id, lab_id=user.lab_id).first()
    if not result:
        raise HTTPException(404, "Result not found")
    result.status = "sent"
    result.sent_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(result)
    return result
