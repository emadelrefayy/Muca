import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_lab_user, CurrentUser

router = APIRouter(prefix="/api/payments", tags=["payments"])


@router.get("", response_model=list[schemas.PaymentOut])
def list_payments(db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    return db.query(models.Payment).filter_by(lab_id=user.lab_id).order_by(models.Payment.created_at.desc()).all()


@router.post("", response_model=schemas.PaymentOut, status_code=201)
def record_payment(body: schemas.PaymentCreate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    order = db.query(models.Order).filter_by(id=body.order_id, lab_id=user.lab_id).first()
    if not order:
        raise HTTPException(404, "Order not found")

    payment = models.Payment(
        lab_id=user.lab_id,
        paid_at=datetime.now(timezone.utc) if body.status == "paid" else None,
        **body.model_dump(),
    )
    db.add(payment)
    db.commit()
    db.refresh(payment)
    return payment


@router.patch("/{payment_id}", response_model=schemas.PaymentOut)
def update_payment(payment_id: uuid.UUID, body: schemas.PaymentUpdate, db: Session = Depends(get_db), user: CurrentUser = Depends(require_lab_user)):
    payment = db.query(models.Payment).filter_by(id=payment_id, lab_id=user.lab_id).first()
    if not payment:
        raise HTTPException(404, "Payment not found")
    data = body.model_dump(exclude_unset=True)
    if data.get("status") == "paid" and payment.status != "paid":
        payment.paid_at = datetime.now(timezone.utc)
    for field, value in data.items():
        setattr(payment, field, value)
    db.commit()
    db.refresh(payment)
    return payment
