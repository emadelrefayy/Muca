import React, { useEffect, useState } from "react";
import { UsersRound, Plus, Pencil } from "lucide-react";
import Modal from "./Modal";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

const empty = { name: "", phone: "", email: "", address: "", notes: "" };

export default function ClientsPage({ t }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // null = closed, {} = new, {...} = edit
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const { data, error: err } = await supabase.from("clients").select("*").order("created_at", { ascending: false });
    if (!err) setRows(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function openNew() { setForm(empty); setEditing({}); setError(""); }
  function openEdit(row) { setForm({ name: row.name, phone: row.phone, email: row.email || "", address: row.address || "", notes: row.notes || "" }); setEditing(row); setError(""); }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const payload = { ...form, lab_id: profile?.lab_id };
    const isNew = !editing?.id;
    const { error: err } = isNew
      ? await supabase.from("clients").insert(payload)
      : await supabase.from("clients").update(form).eq("id", editing.id);
    setSaving(false);
    if (err) { setError(err.message); return; }
    setEditing(null);
    load();
  }

  return (
    <main className="content">
      <div className="page-head">
        <div>
          <h1>{t.clients}</h1>
          <p>{t.clientsSubtitle}</p>
        </div>
        <button className="primary-button" onClick={openNew}><Plus size={16} /> {t.addClient}</button>
      </div>

      <article className="panel">
        <div className="panel-head">
          <h2>{t.allClients}</h2>
        </div>
        <div className="table-scroll">
          {loading ? (
            <div className="table-state">{t.loading}</div>
          ) : rows.length === 0 ? (
            <div className="table-state">
              <UsersRound size={22} />
              <p>{t.noClients}</p>
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>{t.name}</th><th>{t.phone}</th><th>{t.email}</th><th>{t.address}</th><th></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td>{r.name}</td>
                    <td>{r.phone}</td>
                    <td>{r.email || "—"}</td>
                    <td>{r.address || "—"}</td>
                    <td><button className="table-action" onClick={() => openEdit(r)}><Pencil size={15} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </article>

      {editing !== null && (
        <Modal title={editing.id ? t.editClient : t.addClient} onClose={() => setEditing(null)}>
          <form onSubmit={handleSave} className="form-grid">
            <label className="field"><span>{t.name}</span>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </label>
            <label className="field"><span>{t.phone}</span>
              <input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </label>
            <label className="field"><span>{t.email}</span>
              <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </label>
            <label className="field"><span>{t.address}</span>
              <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            </label>
            <label className="field field-full"><span>{t.notes}</span>
              <textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </label>
            {error && <div className="form-error field-full">{error}</div>}
            <div className="modal-actions field-full">
              <button type="button" className="secondary-button" onClick={() => setEditing(null)}>{t.cancel}</button>
              <button type="submit" className="primary-button" disabled={saving}>{saving ? t.saving : t.save}</button>
            </div>
          </form>
        </Modal>
      )}
    </main>
  );
}
