import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { supabase } from "../lib/supabaseClient";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null); // staff row, or null
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [lab, setLab] = useState(null);
  const [loading, setLoading] = useState(true);
  const [profileError, setProfileError] = useState(null);

  const loadProfile = useCallback(async (currentSession) => {
    if (!currentSession) {
      setProfile(null);
      setIsSuperAdmin(false);
      setLab(null);
      return;
    }
    const uid = currentSession.user.id;

    const [{ data: staffRow }, { data: adminRow }] = await Promise.all([
      supabase.from("staff").select("*").eq("auth_user_id", uid).maybeSingle(),
      supabase.from("super_admins").select("*").eq("auth_user_id", uid).maybeSingle(),
    ]);

    setProfile(staffRow || null);
    setIsSuperAdmin(!!adminRow);

    if (staffRow?.lab_id) {
      const { data: labRow } = await supabase.from("labs").select("*").eq("id", staffRow.lab_id).maybeSingle();
      setLab(labRow || null);
    } else {
      setLab(null);
    }

    if (!staffRow && !adminRow) {
      setProfileError(
        "This account isn't linked to a lab yet. Ask your lab manager or Super Admin to add you as staff."
      );
    } else {
      setProfileError(null);
    }
  }, []);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(async ({ data: { session: s } }) => {
      if (!mounted) return;
      setSession(s);
      await loadProfile(s);
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange(async (_event, s) => {
      setSession(s);
      setLoading(true);
      await loadProfile(s);
      setLoading(false);
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const signIn = (email, password) => supabase.auth.signInWithPassword({ email, password });
  const signOut = () => supabase.auth.signOut();

  return (
    <AuthContext.Provider
      value={{ session, profile, isSuperAdmin, lab, loading, profileError, signIn, signOut }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
